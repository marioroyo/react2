import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import UserInput from './UserInput';
import UserOutput from './UserOutput';
import ValidationComponent from './ValidationComponent';
import CharComponent from './CharComponent';

class App extends Component {

  usernameChangedHandler = (event) => {
    this.setState({name: event.target.value});

  }
  state = {
    name: ''
  }
  deletePersonHandler = (index) => {
    // const persons = this.state.persons.slice();
    const persons = this.state.name;
    const textonuevo = persons.split('');
    textonuevo.splice(index, 1);
    const nuevotexto = textonuevo.join('');
    this.setState({name: nuevotexto});
  }
   


  render() {
    let caracteres='';
    let componente=null;
    caracteres=this.state.name.split('');
    let nombre=this.state.name;
    componente = (
      <div>
        {caracteres.map((nombre,index) => {
          return <UserOutput
          click={() => this.deletePersonHandler(index)}
          name={nombre} 
          key={index}
          />
        })}
      </div>

    );

    return (
      <div className="App" >
        <UserInput  changed={this.usernameChangedHandler} currentName={this.state.name} />
        {componente}
        <ValidationComponent longitud={this.state.name.length} />
        </div>
    );
  }
}

export default App;
