import React from 'react';
const CharComponent = (props) => {
    let caracteres='';
        caracteres=props.nombre.split("");
        
        
    return(<p>{caracteres}</p>);
}

export default CharComponent;
