import React from 'react';

const ValidationComponent = (props) => {
    let validation='';
        if (props.longitud < 5) {
            validation="Demasiado corto"
            
        }else{validation="suficientemente largo"}

        
        return(<p>{validation}</p>);
}

export default ValidationComponent;
