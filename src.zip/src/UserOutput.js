import React from 'react';

const UserOutput = (props) => {
    const style = {
        display: 'inline-block',
        border: '1px solid black',
        padding: '16px',
        margin : '16px',
        
      };
    return(
        <div className="salida" style={style}>
            <p type= "text">{props.name}</p>
            <p type= "text">{props.password}</p>

        </div>
    );
}

export default UserOutput;
